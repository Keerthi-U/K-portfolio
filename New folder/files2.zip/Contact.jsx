import { useState } from 'react'
import './Contact.css'

const Contact = () => {
  const [form, setForm] = useState({ email: '', message: '' })

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    alert(`Message sent from ${form.email}!`)
    setForm({ email: '', message: '' })
  }

  return (
    <section className="contact" id="contact">
      <div className="container">
        <div className="contact-card">
          <div className="contact-illustration">
            <img src="https://via.placeholder.com/300x280/2dd4bf/ffffff?text=Contact+Illustration" alt="Contact" />
          </div>

          <div className="contact-form-wrap">
            <h2 className="contact-title">Contact Me!</h2>

            <div className="form-group">
              <label>Email</label>
              <input
                type="email"
                name="email"
                placeholder="Dmark@gmail.com"
                value={form.email}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label>Message</label>
              <input
                type="text"
                name="message"
                placeholder="message"
                value={form.message}
                onChange={handleChange}
              />
            </div>

            <button className="btn-primary contact-btn" onClick={handleSubmit}>
              Send
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Contact
