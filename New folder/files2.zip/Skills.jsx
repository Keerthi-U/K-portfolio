import './Skills.css'

const skills = [
  { name: 'HTML', icon: '🌐', percent: 90 },
  { name: 'CSS', icon: '🎨', percent: 90 },
  { name: 'JavaScript', icon: '⚡', percent: 90 },
  { name: 'Figma', icon: '✏️', percent: 90 },
  { name: 'Python', icon: '🐍', percent: 90 },
  { name: 'C++', icon: '⚙️', percent: 90 },
]

const techBubbles = ['HTML', 'CSS', 'Javascript', 'Bootstrap', 'Git', 'React js', 'PHP', 'Wordpress']

const Skills = () => {
  return (
    <section className="skills" id="about">
      <div className="container skills-grid">
        <div className="skills-left">
          <h2 className="section-title">Why You should Hire me</h2>
          <div className="skill-bars">
            {skills.map(skill => (
              <div key={skill.name} className="skill-row">
                <span className="skill-icon">{skill.icon}</span>
                <div className="skill-bar-wrap">
                  <div className="skill-bar-fill" style={{ width: `${skill.percent}%` }} />
                </div>
                <span className="skill-percent">{skill.percent}%</span>
              </div>
            ))}
          </div>
          <button className="btn-outline" style={{ marginTop: '32px' }}>Check on GITHUB</button>
        </div>

        <div className="skills-right">
          <div className="bubbles-container">
            {techBubbles.map((tech, i) => (
              <div key={tech} className={`bubble bubble-${i}`}>{tech}</div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

export default Skills
