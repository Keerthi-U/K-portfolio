import './Experience.css'

const Experience = () => {
  return (
    <section className="experience" id="experience">
      <div className="container experience-grid">
        <div className="exp-illustration">
          {/* Replace with your illustration */}
          <img src="https://via.placeholder.com/400x320/1a2a4a/2dd4bf?text=Experience+Illustration" alt="Experience" />
        </div>

        <div className="exp-content">
          <div className="shape-circle" style={{ width: 50, height: 50, top: '10%', left: '-5%', position: 'absolute', opacity: 0.3 }} />
          <div className="shape-square" style={{ width: 22, height: 22, top: '20%', right: '5%', position: 'absolute', opacity: 0.3 }} />

          <h2 className="section-title">Experience</h2>
          <p className="exp-description">
            Meet the 7 Baby Steps—the proven plan that shows you exactly what to focus on with
            your money. Even better? When you do the steps in order, they're the fastest way to
            get out of debt and build wealth.
          </p>
          <button className="btn-primary" style={{ marginTop: '24px' }}>See all</button>
        </div>
      </div>
    </section>
  )
}

export default Experience
