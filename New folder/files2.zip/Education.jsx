import './Education.css'

const educationItems = [
  {
    id: 1,
    years: '2014-2015',
    title: 'Software Developer – Cambridge University',
    description: 'A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.',
  },
  {
    id: 2,
    years: '2014-2015',
    title: 'Software Developer – Cambridge University',
    description: 'A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.',
  },
]

const Education = () => {
  return (
    <section className="education" id="education">
      <div className="container">
        <h2 className="section-title">Education</h2>
        <div className="edu-list">
          {educationItems.map(item => (
            <div key={item.id} className="edu-item">
              <div className="edu-icon">
                <span>🎓</span>
              </div>
              <div className="edu-details">
                <p className="edu-years">{item.years}</p>
                <h3 className="edu-title">{item.title}</h3>
                <p className="edu-desc">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Education
