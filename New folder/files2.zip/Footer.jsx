import './Footer.css'

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div className="footer-brand">
          <h3 className="footer-logo">Random</h3>
          <p className="footer-desc">
            Here you can explore your all limits of finance and can get the benefits of our services,
            which will definitely help you to grow financially
          </p>
          <p className="footer-contact">+91 89573876847</p>
          <p className="footer-contact">rendom358@gmail.com</p>
          <div className="footer-socials">
            <a href="#" aria-label="WhatsApp">📱</a>
            <a href="#" aria-label="GitHub">🐙</a>
            <a href="#" aria-label="LinkedIn">💼</a>
            <a href="#" aria-label="YouTube">▶️</a>
            <a href="#" aria-label="Instagram">📷</a>
          </div>
        </div>

        <div className="footer-newsletter">
          <h4 className="footer-col-title">Let start the journey !</h4>
          <input type="email" placeholder="Email" className="footer-input" />
          <button className="btn-primary footer-btn">Subscribe</button>
          <button className="btn-primary footer-btn">Hire me</button>
        </div>

        <div className="footer-links">
          <h4 className="footer-col-title">Important links</h4>
          <ul>
            {['Privacy Policy', 'Cookie Policy', 'Do not disturb', 'Term of Use', 'Secure Usage Tips', 'Disclaimer'].map(link => (
              <li key={link}><a href="#">{link}</a></li>
            ))}
          </ul>
        </div>
      </div>

      <div className="footer-bottom">
        <div className="container">
          <p>© 2024 All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

export default Footer
