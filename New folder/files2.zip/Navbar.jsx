import { useState } from 'react'
import './Navbar.css'

const Navbar = () => {
  const [active, setActive] = useState('Home')
  const links = ['Home', 'About', 'Education', 'Contact']

  return (
    <nav className="navbar">
      <div className="nav-links">
        {links.map(link => (
          <a
            key={link}
            href={`#${link.toLowerCase()}`}
            className={`nav-link ${active === link ? 'active' : ''}`}
            onClick={() => setActive(link)}
          >
            {link}
          </a>
        ))}
      </div>
      <button className="btn-primary hire-btn">Hire Me</button>
    </nav>
  )
}

export default Navbar
