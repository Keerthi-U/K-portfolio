import './Hero.css'

const Hero = () => {
  return (
    <section className="hero" id="home">
      {/* Decorative shapes */}
      <div className="shape-circle" style={{ width: 50, height: 50, top: '20%', left: '18%' }} />
      <div className="shape-square" style={{ width: 24, height: 24, top: '35%', left: '55%', transform: 'rotate(20deg)' }} />
      <div className="shape-circle" style={{ width: 32, height: 32, top: '25%', right: '12%' }} />
      <div className="shape-square" style={{ width: 36, height: 60, bottom: '18%', right: '10%' }} />
      <div className="shape-square" style={{ width: 28, height: 28, bottom: '22%', left: '20%' }} />

      <div className="container hero-content">
        <div className="hero-text">
          <p className="hero-greeting">Hello!</p>
          <h1 className="hero-heading">
            I am <span className="highlight">Ankit Bansal,</span>
            <br />UI/UX designer
          </h1>
          <p className="hero-description">
            Lorem ipsum is goidu ljljgos kjkidl ki kks lgoiuhs lkdhg lkglks lkdse
            lorem ipsum is goidu ljljgos kjkidl ki kks lgoiuhs lkdhg
          </p>
          <div className="hero-buttons">
            <button className="btn-primary">Hire me</button>
            <button className="btn-outline">Hire me</button>
          </div>
        </div>

        <div className="hero-image">
          {/* Replace src with your actual photo */}
          <img src="https://via.placeholder.com/400x500/1a1a2e/2dd4bf?text=Your+Photo" alt="Profile" />
        </div>
      </div>
    </section>
  )
}

export default Hero
